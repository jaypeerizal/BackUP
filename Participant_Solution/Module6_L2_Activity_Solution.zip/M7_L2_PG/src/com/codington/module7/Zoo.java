package com.codington.module7;


 /**
 * The Zoo class can be used to represent zoo at the NewCodington city.
 * It inherits its properties from the RidesHosting interface
 */

public class Zoo implements RidesHosting {

	//TODO 1 - Declare a local private integer variable to hold number of animals value and initialize it to zero.
	private int noOfAnimals = 0;
	//TODO 2 - Declare an array of String to hold animal names and initialize it to empty string.
	String[] animalNames = new String[0];
	//TODO 3- Declare an instance of Safari class with private access modifier and assign null value to it.
	 private Safari safari = new Safari();
	//This Safari class will be composed in Zoo class.
	//TODO 4 - Declare a local private integer variable to hold zoo ride value and initialize it to zero.
	 private int zooRide = 0;
	//TODO 5 - Declare a local private integer variable to hold zoo ride location and initialize it to zero.
	 private int zooRideLocation = 0;
	//TODO 6 - Define getter method for instance variable noOfAnimals.
	//TODO 7 - Define setter method for instance variable noOfAnimals.
	//TODO 8 - Define getter method for instance variable animalNames.
	//TODO 9 - Define setter method for instance variable animalNames.
	//TODO 10 - Define getter method for instance variable safari.
	//TODO 11 - Define setter method for instance variable safari.
	//TODO 12 - Define getter method for instance variable zooRide.
	//TODO 13 - Define setter method for instance variable zooRide.

		public int getNoOfAnimals() {
			return noOfAnimals;
		}


		public void setNoOfAnimals(int noOfAnimals) {
			this.noOfAnimals = noOfAnimals;
		}


		public String[] getAnimalNames() {
			return animalNames;
		}


		public void setAnimalNames(String[] animalNames) {
			this.animalNames = animalNames;
		}


		public Safari getSafari() {
			return safari;
		}


		public void setSafari(Safari safari) {
			this.safari = safari;
		}


		public int getZooRide() {
			return zooRide;
		}


		public void setZooRide(int zooRide) {
			this.zooRide = zooRide;
		}


	public void assignRideCategory() {
		/* TODO 14 - Assigning the high thrill value to the zooRide instance variable.
		 * 	Hint: use the HIGH_THRILL constant defined in the RidesHosting interface
		 */
		zooRide = HIGH_THRILL;
	}


	/**
	 * Method to display ride details based on ride type
	 */
	public String getRideDetails() {

		//TODO 15 i. Create a String variable ride details and initialize it.
		String rideDetails = "taemo";
		//TODO 15 ii. Use if...else loop to check parkRide value.
		//TODO 15 iii. Check if zooRide is equal to RidesHosting.LOW_THRILL
		//		and assign the value "Low Thrill Rides for Children" into the String variable rideDetails.
		//TODO 15 iv. Check if zooRide is equal to RidesHosting.HIGH_THRILL
		//		and store value "High Thrill Rides for Teens and Adults" into ride details.
		//TODO 15 v. return rideDetails.
		if(zooRide == LOW_THRILL){
			rideDetails= "Low Thrill Rides for Children";

		}else if(zooRide == HIGH_THRILL){
			rideDetails = "High Thrill Rides for Teens and Adults";
		}

		return rideDetails;

	}

	/**
	 * Method for assigning RIDETYPE based on the zooRide
	 */
	public void assignRideLocation() {
		//TODO 16. Assign the value of RidesHosting virtual CONSTANT to the member variable for zoo ride location.
		zooRideLocation = VIRTUAL;
		}




	/**
	 * Method for getting RIDETYPE based on the parkRide
	 */
	public String getRideLocation() {
		//TODO 17 a. Define a string variable rideTypeDetails and initialize it with null value;
		String rideTypeDetails = null;

		// TODO b.	Check if parkRideLocation is equal to RidesHosting.INDOOR to set rideTypeDetails value as �Indoor Ride�.
		      //this is supposed to be zooRideLocation ?
		// TODO c.	Check if parkRideLocation is equal to RidesHosting.OUTDOOR to set rideTypeDetails value as �Outdoor Ride�.
		// TODO d.	Check if parkRideLocation is equal to RidesHosting.VIRTUAL to set rideTypeDetails value as �Virtual Ride�.
		// 		Hint: Use if/else loop to check the parkRideLocation value using RidesHosting constants.

		if(zooRideLocation == INDOOR){
		   rideTypeDetails = "Indoor Ride";
		}else if (zooRideLocation == OUTDOOR){
		   rideTypeDetails = "Outdoor Ride";
		}else if (zooRideLocation == VIRTUAL){
		   rideTypeDetails = "Virtual Ride";
		}


		// TODO e: return the value for rideTypeLocation
		return  rideTypeDetails;
	}



}

