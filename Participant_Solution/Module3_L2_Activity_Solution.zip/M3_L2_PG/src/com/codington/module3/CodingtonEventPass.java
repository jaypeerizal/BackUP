
package com.codington.module3;


/**
 *
 * CodingtonEventPass is about buying an entry pass which can be used to attend
 * various events taking place in New Codington.
 *
 * @author jaypee.r.d.altarejos
 **/
public class CodingtonEventPass {

	private static float baseFare = 10;
	private static float serviceTax = 5;
	//TODO 1. Declare a private static  float variable for base fare and initialize it to 10 between class declaration and main() method.
  	//TODO 2. On the next line, declare a private static  float variable for service tax and initialize it to 5 .

	//Create variables of different data types used for displaying information regarding the  event pass inside main() method
	public static void main(String[] args){

		int noOfChildren;
		int noOfAdults;
		String[] entryPass = new String[2];

		entryPass[0] = "Adult";
		entryPass[1] = "Children";
		noOfChildren = 20;
		noOfAdults = 23;

		System.out.println("Hello New Codington Visitors! Select one of the below entry passes:-");

		for(int i = 0; i< entryPass.length; i++ ){

			System.out.println(entryPass[i]);

		}

		System.out.println("Base Fare is " + baseFare);
		System.out.println("Service Tax is " + serviceTax);
		System.out.println("No. of children attending the event is " + noOfChildren);
		System.out.println("No. of children attending the event is " + noOfAdults);

		//TODO 3. Declare an integer variable for number of children attending the event.
  		//TODO 4. Declare an integer variable for number of adults attending the event.
  		//TODO 5.Declare an array of String of size 2 to hold type of entry passes.
  		//TODO 6. Initialize the first element of array with the string value "Adult".
  		//TODO 7. Initialize the second element of array with the string value "Children".
  		//TODO 8. Initialize the value of noOfChildren to 20.
  		//TODO 9. Initialize the value of noOfAdults to 23.
  		//TODO 10. Display a message - 'Hello New Codington Visitors!Select one of the below entry passes:'
  		//TODO 11. Use for loop to iterate over string array and print the different types of entry passes available for the event.
  		//TODO 12. Print the value of base fare.
  		//TODO 13. Print the value of service tax.
  		//TODO 14. Print the number of children taking part in the event.
  		//TODO 15. Print the number of adults taking part in the event.

	}

}
